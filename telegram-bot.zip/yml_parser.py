import requests
from lxml import etree
from io import BytesIO
from config import YML_URL_UA, YML_URL_RU

def parse_yml(xml_bytes):
    root = etree.parse(BytesIO(xml_bytes)).getroot()
    items = root.xpath('//item')
    data = {}
    for item in items:
        id_ = item.find('{http://base.google.com/ns/1.0}id').text
        title = item.find('{http://base.google.com/ns/1.0}title').text
        price_tag = item.find('{http://base.google.com/ns/1.0}sale_price') or item.find('{http://base.google.com/ns/1.0}price')
        price = float(price_tag.text.split()[0])
        avail = item.find('{http://base.google.com/ns/1.0}availability').text == "in stock"
        data[id_] = {"title": title, "price": price, "available": avail}
    return data

async def load_combined_products():
    ua = parse_yml(requests.get(YML_URL_UA).content)
    ru = parse_yml(requests.get(YML_URL_RU).content)
    combined = []
    for id_, val in ua.items():
        if id_ in ru:
            combined.append({
                "id": id_,
                "name_ua": val["title"],
                "name_ru": ru[id_]["title"],
                "price": val["price"],
                "available": val["available"] and ru[id_]["available"]
            })
    return combined
