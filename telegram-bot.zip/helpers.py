
import re

def detect_language(text):
    ua_chars = "іїєґ"
    ru_chars = "ыэёъжшч"
    if any(c in text.lower() for c in ua_chars): return "ua"
    if any(c in text.lower() for c in ru_chars): return "ru"
    return "ua"

def extract_model_and_flavor(name):
    match = re.match(r"^([A-Za-z0-9\s]+)(.*)", name)
    model = match.group(1).strip()
    flavor = match.group(2).strip()
    return model, flavor

def extract_number(text):
    match = re.search(r"(\d{3,6})", text)
    return match.group(1) if match else ""

def match_number_exact(model, query):
    query_num = extract_number(query)
    model_num = extract_number(model)
    return query_num == model_num

def filter_products(products, query):
    query_lc = query.lower()
    has_cyr = bool(re.search(r"[а-яіїєґ]", query_lc))
    result = []
    for p in products:
        name = p["name_ua"] if detect_language(query) == "ua" else p["name_ru"]
        model, flavor = extract_model_and_flavor(name)
        if not p["available"]: continue
        if has_cyr:
            if query_lc in flavor.lower():
                if len(flavor.split()) <= 2:
                    result.append((model, flavor, p["price"]))
        else:
            if match_number_exact(model, query):
                result.append((model, flavor, p["price"]))
    return sorted(result, key=lambda x: (int(extract_number(x[0])), x[1]))

def format_response(matches, lang):
    if not matches:
        return "Нічого не знайдено." if lang == "ua" else "Ничего не найдено."
    header = "Ось що можу запропонувати:" if lang == "ua" else "Вот что могу предложить:"
    lines = [f"{i+1}. {m} {f} - {p}грн" for i, (m, f, p) in enumerate(matches)]
    return header + "\n\n" + "\n".join(lines)
