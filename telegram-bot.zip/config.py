BOT_TOKEN = "8100382645:AAGXrqDpxsGMHNdsknbmfXkR-UR4limLiDA"

YML_URL_UA = "https://palmy.com.ua/marketplace-integration/google-feed?langId=3"
YML_URL_RU = "https://palmy.com.ua/marketplace-integration/google-feed?langId=1"
