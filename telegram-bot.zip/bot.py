import asyncio
from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, ContextTypes, filters
from config import BOT_TOKEN
from yml_parser import load_combined_products
from helpers import detect_language, filter_products, format_response

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.message.text
    language = detect_language(query)
    products = await load_combined_products()
    matched = filter_products(products, query)
    response = format_response(matched, language)
    await update.message.reply_text(response)

if __name__ == "__main__":
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.run_polling()
